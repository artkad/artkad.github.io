<?php

class Auth_model extends CI_Model
{

    public function __construct()
    {

        parent::__construct();
    }

    public function showdata()
    {
        $username = $_SESSION['username'];
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where(array('username' => $username));
        $query = $this->db->get();
        return $query;
    }
    public function updatedata($data,$username)
    {
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where(array('username' => $username));
        $this->db->update('users', $data);
    }
    public function insertdata ($data)
    {
        $this->db->insert('users', $data);
    }
    public function checkuser ($username, $password)
    {
        //check user in database
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where(array('username' => $username, 'password' => $password));
        $query = $this->db->get();
        $user = $query->row();
        return $user;
    }
}