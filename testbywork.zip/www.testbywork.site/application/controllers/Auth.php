<?php
class Auth extends CI_Controller
{
   public function index()
	{
		$this->load->view('login');
		redirect('auth/login', 'refresh');
	}
	
	
    public function logout() {

        unset($_SESSION);
        session_destroy();
        redirect('auth/login', 'refresh');
    }

    public function login()
    {
        if (isset($_POST['login'])) {
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
        if ($this->form_validation->run() == TRUE) {


            $username = $_POST['username'];
            $password = md5($_POST['password']);
            $this->load->model("auth_model");
            $user = $this->auth_model->checkuser($username, $password);
            //if user exist
            if (isset($user->username)) {
                //temporary message
                $this->session->set_flashdata('success', "Вы вошли!");
                //set session variables
                $_SESSION['user_logged'] = TRUE;
                $_SESSION['username'] = $user->username;
                //redirect to profile page
                redirect('user/profile', 'refresh');
            } else {
                $this->session->set_flashdata('error', 'В базе нет такого имени');
                redirect('auth/login', 'refresh');
            }
        }
        }
        $this->load->view('login');
    }
    public function register()
    {
        if (isset($_POST['register'])) {
            $this->form_validation->set_rules('username', 'Username', 'required');
            $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
            $this->form_validation->set_rules('password', 'Confirm Password', 'required|min_length[6] |matches[password]');
            $this->form_validation->set_rules('fio', 'FIO', 'required');
            //if form validation is true
            if ($this->form_validation->run() == TRUE){
            //add user in database
                $data = array(
                    'username' => $_POST['username'],
                    'password' => md5($_POST['password']),
                    'fio' => $_POST['fio'],
                    'birthday' => $_POST['birthday'],
                    'position' => $_POST['position'],
                    'phone' => $_POST['phone']
                );
                $this->load->model("auth_model");
                $this->auth_model->insertdata($data);
                $this->session->set_flashdata('success', 'Ваш аккаунт зарегистрирован.');
                redirect('auth/login', 'refresh');
            }
        }
        //load view
        $this->load->view('register');
    }

    public function edit()
    {
                $this->form_validation->set_rules('position', 'Position', 'required');
                $this->form_validation->set_rules('fio', 'FIO', 'required');
                $this->form_validation->set_rules('birthday', 'Birthday', 'required');
                $this->form_validation->set_rules('phone', 'phone', 'required');
            if ($this->form_validation->run() == TRUE) {
                $username = $_SESSION['username'];
                $newposition = $_POST['position'];
                $newfio = $_POST['fio'];
                $newbirthday = $_POST['birthday'];
                $newphone = $_POST['phone'];
                $data = array(
                    'position' => $newposition,
                    'fio' => $newfio,
                    'birthday' => $newbirthday,
                    'phone' => $newphone
                );
                $this->load->model("auth_model");
                $this->auth_model->updatedata($data,$username);
                $this->session->set_flashdata('success', 'Ваши данные изменены.');
                redirect('user/profile', 'refresh');
            }
        //load view
        $this->load->model("auth_model");
        $data['query'] = $this->auth_model->showdata();
        $this->load->view('edit', $data);

    }
}