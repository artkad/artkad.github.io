<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"> -->
    <link rel='stylesheet' href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">
    <link rel='stylesheet' href="<?php echo base_url(); ?>assets/css/animate.css">
    <title>Edit page</title>
</head>

<body>
<div class="wrapper">
<div class="navbar navbar-expand-md navbar-light bg-dark sticky-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="<?php echo base_url(); ?>index.php/auth/login"><img
                    src="<?php echo base_url(); ?>assets/img/fmc-logo.png"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse"
                data-target="#navbarResponsive">
            <span class="navbar-toggler-icon bg-light"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active"><a href="#" class="nav-link text-light">Вакансии</a></li>
                <li class="nav-item"><a href="#" class="nav-link text-light">Карьера</a></li>
                <li class="nav-item"><a href="#" class="nav-link text-light">Анкета</a></li>
                <li class="nav-item"><a href="#" class="nav-link text-light">О нас</a></li>
                <li class="nav-item"><a href="#" class="nav-link text-light">Отзывы</a></li>
            </ul>
        </div>
    </div>
</div>
<div class="content col-lg-5 offset-lg-2">
    <br>
    <h5>Страница редактирования данных:</h5>
    
    <?php if (isset($_SESSION['success'])) { ?>
        <div class="alert alert-success"><?php echo $_SESSION['success']; ?></div>
        <?php
    } ?>

    <?php echo validation_errors('<div class="alert alert-danger">', '</div>'); ?>
    <form action="" method="post">

        <?php
        foreach ($query->result() as $row) {
            ?>
            <div class="form-group">
                <label for="fio">ФИО:</label>
                <input type="text" class="form-control" name="fio" id='fio' value="<?php echo $row->fio; ?>">
            </div>
            <div class="form-group">
                <label for="birthday">Дата рождения:</label>
                <input type="date" class="form-control" name="birthday" id='birthday'
                       value="<?php echo $row->birthday; ?>">
            </div>
            <div class="form-group">
                <label for="position">Должность:</label>
                <input type="text" class="form-control" name="position" id='position'
                       value="<?php echo $row->position; ?>">
            </div>
            <div class="form-group">
                <label for="phone">Мобильный телефон:</label>
                <input type="text" class="form-control" name="phone" id='phone' value="<?php echo $row->phone; ?>">
            </div>

        <?php }
        ?>

        <div>
            <button class="btn btn-primary bg-dark" name='edit'>Edit</button>
            <a href="<?php echo base_url(); ?>index.php/auth/logout" class="btn btn-primary bg-dark">Выход</a>
        </div>
    </form>


</div>

<footer class="container-fluid">
    <div class="row padding text-center container-center">
        <div class="col-12">
            <h5>Наши контакты</h5>

        </div>
    </div>
</footer>

</div>
<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
        crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
        crossorigin="anonymous"></script>
</body>

</html>
