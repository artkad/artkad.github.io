<?php
class Auth extends CI_Controller
{
    public function index()
	{
		$this->load->view('login');
		redirect('auth/login', 'refresh');
	}
	
	
    public function logout() {

        unset($_SESSION);
        session_destroy();
        redirect('auth/login', 'refresh');
    }

    public function login()
    {
        if (isset($_POST['login'])) {
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
        if ($this->form_validation->run() == TRUE) {


            $username = $_POST['username'];
            $password = md5($_POST['password']);

            //check user in database
            $this->db->select('*');
            $this->db->from('users');
            $this->db->where(array('username' => $username, 'password' => $password));
            $query = $this->db->get();

            $user = $query->row();
            //if user exist
            if ($user->username) {
                //temporary message
                $this->session->set_flashdata('success', "Вы вошли!");
                //set session variables

                $_SESSION['user_logged'] = TRUE;
                $_SESSION['username'] = $user->username;

                //redirect to profile page

                redirect('user/profile', 'refresh');

            } else {
                $this->session->set_flashdata('error', 'В базе нет такого имени');
                redirect('auth/login', 'refresh');
            }
        }
        }
        $this->load->view('login');
    }
    public function register()
    {
        if (isset($_POST['register'])) {
            $this->form_validation->set_rules('username', 'Username', 'required');
            $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
            $this->form_validation->set_rules('password', 'Confirm Password', 'required|min_length[6] |matches[password]');
            $this->form_validation->set_rules('fio', 'FIO', 'required');
            //if form validation is true
            if ($this->form_validation->run() == TRUE){
            //echo 'form validated';
            //add user in database
                $data = array(
                    'username' => $_POST['username'],
                    'password' => md5($_POST['password']),
                    'fio' => $_POST['fio'],
                    'birthday' => $_POST['birthday'],
                    'position' => $_POST['position'],
                    'phone' => $_POST['phone']
                );
                $this->db->insert('users', $data);
                $this->session->set_flashdata('success', 'Ваш аккаунт зарегистрирован.');
                redirect('auth/login', 'refresh');
            }
        }
        //load view
        $this->load->view('register');
    }

    public function edit()
    {
                $this->form_validation->set_rules('position', 'Position', 'required');
                $this->form_validation->set_rules('fio', 'FIO', 'required');
                $this->form_validation->set_rules('birthday', 'Birthday', 'required');
                $this->form_validation->set_rules('phone', 'phone', 'required');
            if ($this->form_validation->run() == TRUE) {
                $username = $_SESSION['username'];
                $newposition = $_POST['position'];
                $newfio = $_POST['fio'];
                $newbirthday = $_POST['birthday'];
                $newphone = $_POST['phone'];
                $data = array(
                    'position' => $newposition,
                    'fio' => $newfio,
                    'birthday' => $newbirthday,
                    'phone' => $newphone
                );
                $this->db->select('*');
                $this->db->from('users');
                $this->db->where(array('username' => $username));

                $this->db->update('users', $data);
                $this->session->set_flashdata('success', 'Ваши данные изменены.');
                redirect('user/profile', 'refresh');
            }

        //load view
        $this->load->view('edit');

    }
}